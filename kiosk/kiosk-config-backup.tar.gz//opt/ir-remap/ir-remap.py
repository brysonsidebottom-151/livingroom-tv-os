#!/usr/bin/env python3
"""Remaps the Mac Mini built-in Apple IR receiver into TV-remote navigation.

Ring (Volume Up/Down): single press = navigate Up/Down.
                        quick double-press = adjust volume by 10% and show
                        a brief on-screen volume bar.
Ring (Back/Forward):    navigate Left/Right.
Center (Play/Pause):    Enter (select).
Menu:                   short press = go back within whatever has focus
                         (Kodi gets Escape/PreviousMenu, anything else
                         such as Firefox gets browser-style Alt+Left).
                         long press = stop Kodi playback, reset Kodi to
                         its default state, and return to the kiosk home
                         screen.

Volume is driven through Kodi's own JSON-RPC Application.SetVolume, not the
system ALSA mixer. Kodi treats any ALSA mixer control attached to its
output device as "its own" hardware volume and actively re-syncs its
internal level onto it (on every stream open, and possibly periodically
during playback), which silently undid external amixer changes -- the
volume bar would slide and the control value would visibly change, but
the next thing Kodi did would stomp it back to whatever it remembered.
Kodi's own JSON-RPC volume is authoritative and nothing fights it.
"""
import json
import os
import subprocess
import threading
import time
import urllib.request

import evdev
from evdev import UInput, ecodes as e

DEVICE_NAME = os.environ.get("IR_REMAP_DEVICE_NAME", "Apple, Inc. IR Receiver")
DOUBLE_CLICK_WINDOW = 0.35  # seconds
LONG_PRESS_THRESHOLD = 0.6  # seconds
VOLUME_STEP = 10
HOME_URL = "http://localhost/home"
KODI_JSONRPC_URL = "http://localhost:8080/jsonrpc"
VOLUME_OSD_SCRIPT = "/opt/volume-osd/show_volume.py"

CAPABILITIES = {
    e.EV_KEY: [
        e.KEY_UP, e.KEY_DOWN, e.KEY_LEFT, e.KEY_RIGHT, e.KEY_ENTER,
        e.KEY_ESC, e.KEY_LEFTALT,
    ]
}


def find_device():
    for path in evdev.list_devices():
        dev = evdev.InputDevice(path)
        if dev.name == DEVICE_NAME:
            return dev
    return None


def kodi_rpc(method, params=None):
    payload = {"jsonrpc": "2.0", "method": method, "id": 1}
    if params is not None:
        payload["params"] = params
    body = json.dumps(payload).encode()
    req = urllib.request.Request(
        KODI_JSONRPC_URL, data=body, headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=2) as resp:
        return json.loads(resp.read())


def show_volume_osd(old_level, new_level):
    subprocess.Popen(
        ["python3", VOLUME_OSD_SCRIPT, str(old_level), str(new_level)],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )


def set_volume(delta):
    def _adjust():
        try:
            current = kodi_rpc(
                "Application.GetProperties", {"properties": ["volume"]}
            )["result"]["volume"]
            new_level = max(0, min(100, current + delta))
            kodi_rpc("Application.SetVolume", {"volume": new_level})
            show_volume_osd(current, new_level)
        except Exception:
            pass

    threading.Thread(target=_adjust, daemon=True).start()


def go_home():
    def _request():
        try:
            urllib.request.urlopen(HOME_URL, timeout=5)
        except Exception:
            pass

    threading.Thread(target=_request, daemon=True).start()


def active_window_name():
    try:
        result = subprocess.run(
            ["xdotool", "getactivewindow", "getwindowname"],
            capture_output=True, text=True, timeout=2,
        )
        return result.stdout.strip()
    except Exception:
        return ""


class RingButton:
    """Tracks pending single-press vs. double-press for one ring direction."""

    def __init__(self, single_action, double_action):
        self.single_action = single_action
        self.double_action = double_action
        self.timer = None
        self.lock = threading.Lock()

    def press(self):
        with self.lock:
            if self.timer is not None:
                self.timer.cancel()
                self.timer = None
                self.double_action()
            else:
                self.timer = threading.Timer(DOUBLE_CLICK_WINDOW, self._fire_single)
                self.timer.start()

    def _fire_single(self):
        with self.lock:
            self.timer = None
        self.single_action()


class HoldButton:
    """Tracks short-press vs. long-press (hold-and-release) for one button."""

    def __init__(self, short_action, long_action, threshold):
        self.short_action = short_action
        self.long_action = long_action
        self.threshold = threshold
        self.press_time = None

    def down(self):
        self.press_time = time.monotonic()

    def up(self):
        if self.press_time is None:
            return
        held = time.monotonic() - self.press_time
        self.press_time = None
        if held >= self.threshold:
            self.long_action()
        else:
            self.short_action()


def main():
    dev = find_device()
    if dev is None:
        raise SystemExit(f"Device '{DEVICE_NAME}' not found")

    dev.grab()
    ui = UInput(CAPABILITIES, name="ir-remap-virtual-keyboard")

    def tap(code):
        ui.write(e.EV_KEY, code, 1)
        ui.write(e.EV_KEY, code, 0)
        ui.syn()

    def alt_left():
        ui.write(e.EV_KEY, e.KEY_LEFTALT, 1)
        ui.syn()
        ui.write(e.EV_KEY, e.KEY_LEFT, 1)
        ui.write(e.EV_KEY, e.KEY_LEFT, 0)
        ui.syn()
        ui.write(e.EV_KEY, e.KEY_LEFTALT, 0)
        ui.syn()

    def go_back():
        name = active_window_name()
        if "Kodi" in name:
            tap(e.KEY_ESC)
        else:
            alt_left()

    up_button = RingButton(lambda: tap(e.KEY_UP), lambda: set_volume(VOLUME_STEP))
    down_button = RingButton(lambda: tap(e.KEY_DOWN), lambda: set_volume(-VOLUME_STEP))
    menu_button = HoldButton(go_back, go_home, LONG_PRESS_THRESHOLD)

    print(f"Listening on {dev.path} ({dev.name})", flush=True)
    for ev in dev.read_loop():
        if ev.type != e.EV_KEY:
            continue

        if ev.code == e.KEY_MENU:
            if ev.value == 1:
                menu_button.down()
            elif ev.value == 0:
                menu_button.up()
            continue

        if ev.value != 1:  # key-down only for everything else
            continue
        if ev.code == e.KEY_VOLUMEUP:
            up_button.press()
        elif ev.code == e.KEY_VOLUMEDOWN:
            down_button.press()
        elif ev.code == e.KEY_BACK:
            tap(e.KEY_LEFT)
        elif ev.code == e.KEY_FORWARD:
            tap(e.KEY_RIGHT)
        elif ev.code in (e.KEY_PLAYPAUSE, e.KEY_ENTER):
            tap(e.KEY_ENTER)


if __name__ == "__main__":
    main()
